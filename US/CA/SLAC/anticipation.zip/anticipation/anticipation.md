Anticipation GridLAB-D Template

# Synopsis

~~~
sh% gridlabd -D OUTPUT=<folder> <settings>.glm <network>.glm <recorders>.glm <template-dir>/anticipation.glm
~~~

# Description

## Template Files
